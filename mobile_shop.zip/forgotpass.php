<div class="block">
  <h1>Quên mật khẩu</h1>
  <form name="forgotpass" action="?page=forgotpass_query" method="POST" />
  <span style="font-weight:bold">Điền vào email hoặc tên đăng nhập của bạn:</span>  
  <br />
  <p style="padding:1px;">Mật khẩu mới sẽ được gửi vào email của bạn</p>
    <input type="text" style="height:20px" name="info" size="30" />
    <input type="submit" style="padding:4px 30px" name="forgot_submit" value="OK" />
  </form>
</div>
