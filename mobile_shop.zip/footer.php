
  <div id="footer">
    <p> &copy; 2011 <strong>Nhóm 4 - C1101L - Giảng viên: Lưu Anh Quyền </strong> &nbsp;&nbsp; Design by: <a href="http://www.styleshout.com/">styleshout</a> | Valid: <a href="http://validator.w3.org/check/referer">XHTML</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="<?echo $site_url;?>">Trang chủ</a>&nbsp;|&nbsp; <a href="<?echo $site_url;?>">Về chúng tôi</a>&nbsp;</p>
  </div>
</div>
</body>
</html>
<?php
mysql_close($con);
?>	
