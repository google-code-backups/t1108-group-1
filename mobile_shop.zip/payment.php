<?
    $_SESSION['payment'] = 'paid';
?>
