<?
$set_prev_page = 0;
logout_user();
returnPage_user();
?>
